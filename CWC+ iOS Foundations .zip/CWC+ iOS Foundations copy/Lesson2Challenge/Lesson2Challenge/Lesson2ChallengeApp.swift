//
//  Lesson2ChallengeApp.swift
//  Lesson2Challenge
//
//  Created by Shon Bennett on 1/17/22.
//

import SwiftUI

@main
struct Lesson2ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
